import React, { useState, useMemo } from 'react';
import { Smartphone, User, DollarSign, Calendar, Calculator, CheckCircle2, AlertCircle, Layers, Save } from 'lucide-react';
import { cn } from '../../lib/utils';
import { useCustomerStore } from '../../store/useCustomerStore';
import { useSaleStore } from '../../store/useSaleStore';
import { useFinanceStore, Installment } from '../../store/useFinanceStore';
import { useInventoryStore } from '../../store/useInventoryStore';
import { useUI } from '../../context/UIContext';
import { useAuthStore } from '../../store/useAuthStore';

interface SaleFormProps {
  onSuccess: () => void;
  onCancel: () => void;
}

export default function SaleForm({ onSuccess, onCancel }: SaleFormProps) {
  const { customers } = useCustomerStore();
  const { addSale } = useSaleStore();
  const { addInstallments } = useFinanceStore();
  const { inventory, updateItem } = useInventoryStore();
  const { showNotification, hideModal } = useUI();
  const { profile } = useAuthStore();

  const [formData, setFormData] = useState({
    customer_id: '',
    device_id: '',
    device_model: '',
    imei: '',
    total_value: 0,
    down_payment: 0,
    installments: 12,
    first_due_date: new Date().toISOString().split('T')[0]
  });

  const availableDevices = useMemo(() => 
    inventory.filter(item => item.status === 'available'), 
  [inventory]);

  const handleDeviceChange = (deviceId: string) => {
    const device = inventory.find(d => d.id === deviceId);
    if (device) {
      setFormData(prev => ({
        ...prev,
        device_id: deviceId,
        device_model: device.model,
        imei: device.imei,
        total_value: device.price
      }));
    } else {
      setFormData(prev => ({
        ...prev,
        device_id: '',
        device_model: '',
        imei: '',
        total_value: 0
      }));
    }
  };

  const selectedCustomer = customers.find(c => c.id === formData.customer_id);

  const installmentValue = useMemo(() => {
    const financed = formData.total_value - formData.down_payment;
    return financed > 0 ? financed / formData.installments : 0;
  }, [formData.total_value, formData.down_payment, formData.installments]);

  const generatedInstallments = useMemo(() => {
    if (!formData.customer_id || formData.total_value <= 0) return [];

    const preview: any[] = [];
    const baseDate = new Date(formData.first_due_date);

    for (let i = 1; i <= formData.installments; i++) {
      const dueDate = new Date(baseDate);
      dueDate.setMonth(baseDate.getMonth() + (i - 1));
      
      preview.push({
        number: i,
        total: formData.installments,
        value: installmentValue,
        dueDate: dueDate.toISOString().split('T')[0],
        status: 'pending'
      });
    }
    return preview;
  }, [formData, installmentValue]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.customer_id || !formData.device_model || formData.total_value <= 0) {
      showNotification('error', 'Campos Obrigatórios', 'Por favor, preencha todos os campos corretamente.');
      return;
    }

    try {
      // 1. Add Sale
      await addSale({
        unit_id: profile?.unit_id || undefined,
        customer_id: formData.customer_id,
        device_model: formData.device_model,
        imei: formData.imei,
        total_value: formData.total_value,
        down_payment: formData.down_payment,
        installments: formData.installments,
        date: new Date().toISOString().split('T')[0],
        status: 'completed'
      });

      // 2. Mark Device as Sold if applicable
      if (formData.device_id) {
        await updateItem(formData.device_id, { status: 'sold' });
      }
      
      showNotification('success', 'Venda Registrada');
      onSuccess();
      hideModal();
    } catch (error) {
      showNotification('error', 'Erro ao registrar venda');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Customer Section */}
        <div className="space-y-2">
          <label className="text-[10px] font-black text-on-surface/60 uppercase tracking-widest pl-1">Cliente</label>
          <select 
            required
            value={formData.customer_id}
            onChange={(e) => setFormData(prev => ({ ...prev, customer_id: e.target.value }))}
            className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-sm text-on-surface focus:border-primary outline-none transition-all appearance-none"
          >
            <option value="" className="bg-surface-container-high">Selecionar Cliente...</option>
            {customers.map(c => (
              <option key={c.id} value={c.id} className="bg-surface-container-high">{c.name} - {c.cpf}</option>
            ))}
          </select>
        </div>

        {/* Selection Strategy Section */}
        <div className="space-y-2">
          <label className="text-[10px] font-black text-on-surface/60 uppercase tracking-widest pl-1">Vincular do Estoque</label>
          <select 
            value={formData.device_id}
            onChange={(e) => handleDeviceChange(e.target.value)}
            className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-sm text-on-surface focus:border-primary outline-none transition-all appearance-none"
          >
            <option value="" className="bg-surface-container-high">-- Entrada Manual --</option>
            {availableDevices.map(d => (
              <option key={d.id} value={d.id} className="bg-surface-container-high">{d.model} - {d.imei}</option>
            ))}
          </select>
        </div>

        {/* Device Section */}
        <div className="space-y-2">
          <label className="text-[10px] font-black text-on-surface/60 uppercase tracking-widest pl-1">Modelo do Aparelho</label>
          <input 
            type="text" 
            required
            placeholder="Ex: iPhone 15 Pro Max"
            value={formData.device_model}
            onChange={(e) => setFormData(prev => ({ ...prev, device_model: e.target.value }))}
            readOnly={!!formData.device_id}
            className={cn(
              "w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-sm text-on-surface focus:border-primary outline-none transition-all",
              formData.device_id && "opacity-50 cursor-not-allowed"
            )}
          />
        </div>

        <div className="space-y-2">
          <label className="text-[10px] font-black text-on-surface/60 uppercase tracking-widest pl-1">IMEI / Serial</label>
          <input 
            type="text" 
            required
            placeholder="Número do IMEI"
            value={formData.imei}
            onChange={(e) => setFormData(prev => ({ ...prev, imei: e.target.value }))}
            readOnly={!!formData.device_id}
            className={cn(
              "w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-sm text-on-surface focus:border-primary outline-none transition-all",
              formData.device_id && "opacity-50 cursor-not-allowed"
            )}
          />
        </div>

        <div className="space-y-2">
          <label className="text-[10px] font-black text-on-surface/60 uppercase tracking-widest pl-1">Valor Total (R$)</label>
          <input 
            type="number" 
            required
            placeholder="0.00"
            value={formData.total_value || ''}
            onChange={(e) => setFormData(prev => ({ ...prev, total_value: Number(e.target.value) }))}
            readOnly={!!formData.device_id}
            className={cn(
              "w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-sm text-on-surface focus:border-primary outline-none transition-all",
              formData.device_id && "opacity-50 cursor-not-allowed"
            )}
          />
        </div>

        <div className="space-y-2">
          <label className="text-[10px] font-black text-on-surface/60 uppercase tracking-widest pl-1">Entrada (R$)</label>
          <input 
            type="number" 
            placeholder="0.00"
            value={formData.down_payment || ''}
            onChange={(e) => setFormData(prev => ({ ...prev, down_payment: Number(e.target.value) }))}
            className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-sm text-on-surface focus:border-primary outline-none transition-all"
          />
        </div>

        <div className="space-y-2">
          <label className="text-[10px] font-black text-on-surface/60 uppercase tracking-widest pl-1">Parcelas</label>
          <select 
            value={formData.installments}
            onChange={(e) => setFormData(prev => ({ ...prev, installments: Number(e.target.value) }))}
            className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-sm text-on-surface focus:border-primary outline-none transition-all appearance-none"
          >
            {[1, 2, 3, 6, 10, 12, 18, 24].map(n => (
              <option key={n} value={n} className="bg-surface-container-high">{n} Parcela(s)</option>
            ))}
          </select>
        </div>

        <div className="space-y-2">
          <label className="text-[10px] font-black text-on-surface/60 uppercase tracking-widest pl-1">1º Vencimento</label>
          <input 
            type="date" 
            value={formData.first_due_date}
            onChange={(e) => setFormData(prev => ({ ...prev, first_due_date: e.target.value }))}
            className="w-full bg-white/5 border border-white/10 rounded-2xl px-5 py-4 text-sm text-on-surface focus:border-primary outline-none transition-all"
          />
        </div>
      </div>

      {/* Preview Section */}
      {generatedInstallments.length > 0 && (
        <div className="mt-8 p-6 bg-white/5 rounded-[32px] border border-white/10">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-[10px] font-black text-white uppercase tracking-[0.2em]">Resumo do Contrato</h4>
            <div className="text-right">
              <p className="text-[8px] text-on-surface-variant font-black uppercase tracking-widest">Valor da Parcela</p>
              <p className="text-lg font-black text-white font-mono">R$ {installmentValue.toFixed(2)}</p>
            </div>
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {generatedInstallments.slice(0, 4).map((inst, i) => (
              <div key={i} className="bg-white/5 p-3 rounded-2xl border border-white/5 text-center">
                <p className="text-[8px] font-black text-on-surface-variant uppercase tracking-widest mb-1">Parcela {inst.number}</p>
                <p className="text-[10px] font-black text-white">{new Date(inst.dueDate!).toLocaleDateString('pt-BR')}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="flex gap-4 pt-4">
        <button 
          type="button"
          onClick={onCancel}
          className="flex-1 py-4 px-6 rounded-2xl bg-white/5 border border-white/10 text-[10px] font-black uppercase tracking-widest text-on-surface-variant hover:text-white transition-all"
        >
          Cancelar
        </button>
        <button 
          type="submit"
          className="flex-[2] py-4 px-6 rounded-2xl bg-primary text-on-primary text-[10px] font-black uppercase tracking-widest transition-all hover:scale-[1.02] active:scale-95 shadow-lg shadow-primary/20 flex items-center justify-center gap-2"
        >
          <Save size={16} /> Finalizar Venda
        </button>
      </div>
    </form>
  );
}
